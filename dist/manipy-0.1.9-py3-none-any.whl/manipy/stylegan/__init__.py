from .core import setup_stylegan
from .utils import *
